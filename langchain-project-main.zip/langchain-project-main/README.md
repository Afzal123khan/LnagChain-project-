# langchain-project
[book recommendation](https://srikanth-18066.streamlit.app/)
